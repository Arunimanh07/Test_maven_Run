package com.example.quote.util;

import com.example.quote.model.Quote;
import org.apache.commons.lang3.StringUtils;

public class TextFormatter {

    public static String formatQuote(Quote quote) {
        String text = StringUtils.capitalize(quote.getText());
        String author = StringUtils.upperCase(quote.getAuthor());

        return "\""+ text +"\"\n  - " + author;
    }
}
