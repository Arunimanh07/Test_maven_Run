package com.example.quote;

import com.example.quote.service.QuoteService;
import com.example.quote.util.TextFormatter;
import com.example.quote.model.Quote;

public class MainApp {
    public static void main(String[] args) {
        QuoteService service = new QuoteService();

        for (int i = 0; i < 3; i++) {
            Quote quote = service.getRandomQuote();
            String formatted = TextFormatter.formatQuote(quote);
            System.out.println(formatted);
            System.out.println("----------------------------------");
        }
    }
}
