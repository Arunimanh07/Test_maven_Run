package com.example.quote.service;

import com.example.quote.model.Quote;
import java.util.List;
import java.util.Random;

public class QuoteService {

    private final List<Quote> quotes = List.of(
        new Quote("Be yourself; everyone else is already taken.", "Oscar Wilde"),
        new Quote("Stay hungry, stay foolish.", "Steve Jobs"),
        new Quote("Code is like humor. When you have to explain it, it’s bad.", "Cory House"),
        new Quote("Simplicity is the soul of efficiency.", "Austin Freeman")
    );

    private final Random random = new Random();

    public Quote getRandomQuote() {
        return quotes.get(random.nextInt(quotes.size()));
    }
}
